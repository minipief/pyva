# -*- coding: utf-8 -*-
"""
Created on Sat Aug 10 14:34:36 2019

"""

import pyva.data.matrixClasses as mC

x = mC.DataAxis.octave_band(500,1000)