# -*- coding: utf-8 -*-
"""
Subpackage for loads handling

Currently very simple, because only deterministic nodal loads are implemented

"""

__all__ = ["loadCase.py"]